/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula.pkg2.projeto.pkg2.pkg2.bimestre;

/**
 *
 * @author kamilie.msilva
 */
public class Aula2Projeto22Bimestre {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
